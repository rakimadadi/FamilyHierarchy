package com.demo.familytree.pojo;

import java.io.Serializable;
import java.util.List;

public class Person implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String name = "";
	private String spouse = "";
	private List<Person> children;
	private Person parent;
	private Person spouseParent;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSpouse() {
		return spouse;
	}

	public void setSpouse(String spouse) {
		this.spouse = spouse;
	}

	public List<Person> getChildren() {
		return children;
	}

	public void setChildren(List<Person> children) {
		this.children = children;
	}

	public Person getParent() {
		return parent;
	}

	public void setParent(Person parent) {
		this.parent = parent;
	}

	public Person getSpouseParent() {
		return spouseParent;
	}

	public void setSpouseParent(Person spouseParent) {
		this.spouseParent = spouseParent;
	}
}
