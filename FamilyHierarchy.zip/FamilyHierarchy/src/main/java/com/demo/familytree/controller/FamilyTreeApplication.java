package com.demo.familytree.controller;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.demo.familytree.config.AppConfig;
import com.demo.familytree.pojo.Person;
import com.demo.familytree.util.FamilyUtil;

@SpringBootApplication(exclude = { SecurityAutoConfiguration.class })
public class FamilyTreeApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(FamilyTreeApplication.class, args);
		
		AnnotationConfigApplicationContext context 
	      = new AnnotationConfigApplicationContext(AppConfig.class);	    
		
		List<Person> familyTree = FamilyUtil.addFamilyHierarchy(context);
		for (String arg : args) {
			   System.out.println(arg);
			FamilyUtil.fetchGrandParents(familyTree, arg);
			FamilyUtil.fetchGrandChildren(familyTree, arg);
		}		
	}

}
