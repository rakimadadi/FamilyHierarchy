package com.demo.familytree.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;

import com.demo.familytree.util.FamilyUtil;

@SpringBootApplication(exclude = { SecurityAutoConfiguration.class })
public class FamilyTreeApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(FamilyTreeApplication.class, args);		
		try {
			FamilyUtil.addFamilyTree(args);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
