package com.demo.familytree.pojo;

import java.util.List;

public interface Node {

	public String getName();
	public Integer getAge();
	public Node getRoot();
	public void setRoot(Node root);
	public void setParent(Node parent);
	public Node getParent();
	public void setSpouse(Node parent);
	public Node getSpouse();
	public void addChild(Node child);
	public void addChildren(List<Node> children);
	public List<Node> getChildren();	
}
