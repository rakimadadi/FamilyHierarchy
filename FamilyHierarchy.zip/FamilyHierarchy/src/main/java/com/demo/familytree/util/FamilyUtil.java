package com.demo.familytree.util;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import com.demo.familytree.pojo.Node;
import com.demo.familytree.pojo.PersonNode;

public class FamilyUtil {

	public static Node setPerson(String member) {
		Node person = null;
		String[] nameAge = null;
		if (member != null) {
			nameAge = member.split("~");
		}
		if (nameAge != null && nameAge.length > 0) {
			person = new PersonNode(nameAge[0], Integer.parseInt(nameAge[1]));
		}
		return person;
	}

	public static Node addFamilyTree(String[] hierarchyArr) throws Exception {

		TreeSet<Node> familyTree = new TreeSet<>();
		try {
			if (hierarchyArr != null && hierarchyArr.length > 0) {
				Map<String, String> hierarchyMap = new HashMap<>();
				for (String hier : hierarchyArr) {
					String[] str = hier.split("-");
					hierarchyMap.put(str[0], str[1]);
				}
				if (!hierarchyMap.isEmpty()) {
					Node ggParentNode = null;
					Node gParentNode = null;
					Node parentNode = null;
					Node personNode = null;
					if (hierarchyMap.containsKey("GGP")) {
						ggParentNode = setPerson(hierarchyMap.get("GGP"));
						if (ggParentNode != null) {
							System.out.println("GGP is : " + ggParentNode.getName() + " and age is : " + ggParentNode.getAge());
							familyTree.add(ggParentNode);
						}
					}
					gParentNode = fetchParentRelation(hierarchyMap, ggParentNode, "GP", familyTree);
					parentNode = fetchParentRelation(hierarchyMap, gParentNode, "Parent", familyTree);
					personNode = generatePersonNode(familyTree, hierarchyMap, parentNode);
					familyTree.add(personNode);					
					descendingOrderAsPerAge(familyTree);
					return personNode;
				} else {
					System.out.println("Please enter a valid input");
				}
			} else {
				System.out.println("Please enter a valid input");
			}

		} catch (Exception e) {
			throw new Exception(e);
		}
		return new PersonNode("", 0);
	}

	private static void descendingOrderAsPerAge(TreeSet<Node> familyTree) {

		TreeSet<Node> descOrderedFamily = new TreeSet<>(new Comparator<Node>() {
			@Override
			public int compare(Node o1, Node o2) {
				int ageComp = o2.getAge().compareTo(o1.getAge());
				// additional check if Age is same
				if (ageComp != 0) {
					return ageComp;
				}
				return o1.getName().compareTo(o2.getName());
			}
		});

		descOrderedFamily.addAll(familyTree);
		for (Node node : descOrderedFamily) {
			System.out.println("Name is : " + node.getName() + " and Age in Descending Order : " + node.getAge());
		}
	}

	/**
	 * @param familyTree
	 * @param hierarchyMap
	 * @param parentNode
	 * @param personNode
	 * @return
	 */
	private static Node generatePersonNode(TreeSet<Node> familyTree, Map<String, String> hierarchyMap,
			Node parentNode) {
		Node personNode = null;
		if (hierarchyMap.containsKey("Person")) {
			personNode = setPerson(hierarchyMap.get("Person"));
			if (parentNode != null && personNode != null) {
				// Adding as parent
				personNode.setParent(parentNode);
				// Adding as child
				parentNode.addChild(personNode);
				System.out.println("Person" + " is : " + personNode.getName() + " and age is : " + personNode.getAge());
				// add Spouse
				if (hierarchyMap.containsKey("Spouse")) {
					Node spouse = setPerson(hierarchyMap.get("Spouse"));
					personNode.setSpouse(spouse);
					System.out.println("Spouse" + " is : " + spouse.getName() + " and age is : " + spouse.getAge());
					familyTree.add(spouse);
				}
				// add Children
				List<Node> childrenNodes = new ArrayList<>();
				if (hierarchyMap.containsKey("Children")) {
					addChildrenToParent(hierarchyMap, childrenNodes, personNode, familyTree);
				}
				personNode.addChildren(childrenNodes);
			}
		}
		return personNode;
	}

	/**
	 * @param hierarchyMap
	 * @param childrenNodes
	 * @param familyTree
	 * @param children
	 */
	private static void addChildrenToParent(Map<String, String> hierarchyMap, List<Node> childrenNodes, Node person,
			TreeSet<Node> familyTree) {
		String[] children = hierarchyMap.get("Children").split("!");
		if (children != null && children.length > 0) {
			for (String child : children) {
				Node childNode = setPerson(child);
				if (childNode != null) {
					childNode.setParent(person);
					childrenNodes.add(childNode);
					System.out.println("Child" + " is : " + childNode.getName() + " and age is : " + childNode.getAge());
					familyTree.add(childNode);
					// add GrandChildren
					if (childNode.getName() != null && hierarchyMap.containsKey("GC")) {
						addGrandChild(hierarchyMap, childNode, familyTree);
					}
				}
			}
		}
	}

	/**
	 * @param hierarchyMap
	 * @param childNode
	 * @param familyTree
	 */
	private static void addGrandChild(Map<String, String> hierarchyMap, Node childNode, TreeSet<Node> familyTree) {
		String[] grandChildren = hierarchyMap.get("GC").split("#");
		if (grandChildren != null && grandChildren.length > 0 && grandChildren[0].equals(childNode.getName())) {
			String[] grandChildArr = grandChildren[1].split("!");
			if (grandChildArr != null && grandChildArr.length > 0) {
				for (String grandChild : grandChildArr) {
					Node grandChildNode = setPerson(grandChild);
					childNode.addChild(grandChildNode);
					System.out.println("Grand Child " + " is : " + grandChildNode.getName() + " and age is : " + grandChildNode.getAge());
					familyTree.add(grandChildNode);
				}
			}
		}
	}

	/**
	 * @param hierarchyMap
	 * @param familyTree
	 * @param ggParentNode
	 * @param gParentNode
	 * @return
	 */
	private static Node fetchParentRelation(Map<String, String> hierarchyMap, Node parentNode, String identifier,
			TreeSet<Node> familyTree) {
		Node node = null;
		if (hierarchyMap.containsKey(identifier)) {
			node = setPerson(hierarchyMap.get(identifier));
			if (parentNode != null && node != null) {
				// Adding as parent
				node.setParent(parentNode);
				// Adding as child
				parentNode.addChild(node);
				System.out.println(identifier + " is : " + node.getName() + " and age is : " + node.getAge());
			}
			familyTree.add(node);
		}
		return node;
	}
}