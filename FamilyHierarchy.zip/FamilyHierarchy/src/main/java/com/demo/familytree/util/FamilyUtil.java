package com.demo.familytree.util;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.demo.familytree.pojo.Person;

public class FamilyUtil {

	public static List<Person> addFamilyHierarchy(AnnotationConfigApplicationContext context) {
		
		List<Person> familyTree = new ArrayList<>();
		
		Person motilal = context.getBean(Person.class);;
		motilal.setName("Motilal");
		List<Person> motilalChildren = new ArrayList<>();

		Person jawahar = context.getBean(Person.class);;
		jawahar.setName("Jawahar");
		jawahar.setSpouse("Kamala");
		jawahar.setParent(motilal);

		List<Person> jChildren = new ArrayList<>();
		Person priyadarishini = context.getBean(Person.class);;
		priyadarishini.setName("Priyadarishini");
		priyadarishini.setSpouse("Feroz");
		priyadarishini.setParent(jawahar);
		List<Person> priyaChildren = new ArrayList<>();

		Person sanjay = context.getBean(Person.class);;
		sanjay.setName("Sanjay");
		sanjay.setSpouse("Maneka");
		sanjay.setParent(priyadarishini);
		priyaChildren.add(sanjay);
		List<Person> sanjayChildren = new ArrayList<>();

		Person varun = context.getBean(Person.class);;
		varun.setName("Varun");
		varun.setParent(sanjay);
		sanjayChildren.add(varun);
		sanjay.setChildren(sanjayChildren);

		Person rajeev = context.getBean(Person.class);;
		rajeev.setName("Rajeev");
		rajeev.setSpouse("Sonia");
		rajeev.setParent(priyadarishini);
		priyaChildren.add(rajeev);
		List<Person> rajeevChildren = new ArrayList<>();

		Person priyanka = context.getBean(Person.class);;
		priyanka.setName("Priyanka");
		priyanka.setParent(rajeev);
		rajeevChildren.add(priyanka);

		Person rahul = context.getBean(Person.class);;
		rahul.setName("Rahul");
		rahul.setParent(rajeev);
		rajeevChildren.add(rahul);
		rajeev.setChildren(rajeevChildren);

		priyadarishini.setChildren(priyaChildren);
		jChildren.add(priyadarishini);

		Person vijayalakshmi = context.getBean(Person.class);
		vijayalakshmi.setName("Vijayalakshmi");
		vijayalakshmi.setParent(jawahar);
		jChildren.add(vijayalakshmi);

		jawahar.setChildren(jChildren);

		motilalChildren.add(jawahar);
		motilal.setChildren(motilalChildren);

		familyTree.add(motilal);
		familyTree.add(jawahar);
		familyTree.add(vijayalakshmi);
		familyTree.add(priyadarishini);
		familyTree.add(sanjay);
		familyTree.add(varun);

		familyTree.add(rajeev);
		familyTree.add(priyanka);
		familyTree.add(rahul);

		return familyTree;
	}

	public static void fetchGrandParents(List<Person> familyTree, String searchName) {

		System.out.println("Searching Grandparents for : " + searchName);
		int count = 0;
		if (searchName != null && !"".equalsIgnoreCase(searchName)) {
			for (Person family : familyTree) {
				if (searchName.equalsIgnoreCase(family.getName())) {
					Person parent = family.getParent();
					getGrandParentByParent(parent);
					count++;
					break;
				} else if (searchName.equalsIgnoreCase(family.getSpouse())) {
					Person parent = family.getSpouseParent();
					getGrandParentByParent(parent);
					count++;
					break;

				} else if (family.getChildren() != null && family.getChildren().size() > 0) {
					List<Person> children = family.getChildren();
					for (Person child : children) {
						if (searchName.equalsIgnoreCase(child.getName())) {
							searchForGrandParent(family);
							count++;
							break;
						}
					}
					if (count > 0) {
						break;
					}
				}
			}
			if (count == 0) {
				System.out.println("Grand Parents doesn't exist");
			}
		} else {
			System.out.println("Person Name is not valid : " + searchName);
		}
	}

	/**
	 * @param parent
	 */
	private static void getGrandParentByParent(Person parent) {
		if (parent != null) {
			searchForGrandParent(parent);
		} else {
			System.out.println("Grand Parents doesn't exist");
		}
	}

	/**
	 * @param parent
	 */
	private static void searchForGrandParent(Person parent) {
		Person grandParent = parent.getParent();
		if (grandParent != null) {
			System.out.println(
					"Grand Parents are " + grandParent.getName() + " and " + grandParent.getSpouse());
		} else {
			System.out.println("Grand Parents doesn't exist");
		}
	}

	public static void fetchGrandChildren(List<Person> familyTree, String searchName) {

		int count = 0;
		if (searchName != null && !"".equalsIgnoreCase(searchName)) {
			for (Person family : familyTree) {
				if ((searchName.equalsIgnoreCase(family.getName())
						|| searchName.equalsIgnoreCase(family.getSpouse()))) {
					count = getGrandChildren(count, family);
					if (count == 0) {
						System.out.println("Grand Children doesn't exist");
					}
					// In case if there are no Grand Children and to exit out of outer most loop.
					count++;
					break;
				} else if (family.getChildren() != null && family.getChildren().size() > 0) {
					List<Person> children = family.getChildren();
					for (Person child : children) {
						if (searchName.equalsIgnoreCase(child.getName())) {
							count = getGrandChildren(count, child);
							if (count == 0) {
								System.out.println("Grand Children doesn't exist");
							}
							// In case if there are no Grand Children and to exit out of outer most loop.
							count++;
							break;
						}
					}
					if (count > 0) {
						break;
					}
				}
			}
			if (count == 0) {
				System.out.println("Grand Children doesn't exist");
			}
		} else {
			System.out.println("Person Name is not valid : " + searchName);
		}
	}

	/**
	 * @param count
	 * @param family
	 * @return
	 */
	private static int getGrandChildren(int count, Person family) {
		List<Person> children = family.getChildren();
		if (children != null && children.size() > 0) {
			for (Person child : children) {
				List<Person> grandChildren = child.getChildren();
				if (grandChildren != null && grandChildren.size() > 0) {
					for (Person grandChild : grandChildren) {
						System.out.println("Grand Children are " + grandChild.getName());
					}
					count++;
				}
			}
		}
		return count;
	}

}
