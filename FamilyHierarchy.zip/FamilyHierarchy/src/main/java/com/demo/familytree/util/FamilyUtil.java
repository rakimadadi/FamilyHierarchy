package com.demo.familytree.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.demo.familytree.pojo.Node;
import com.demo.familytree.pojo.PersonNode;

public class FamilyUtil {

	public static Node setPerson(String member) {
		Node person = null;
		String[] nameAge = null;
		if (member != null) {
			nameAge = member.split("~");
		}
		if (nameAge != null && nameAge.length > 0) {
			person = new PersonNode(nameAge[0], Integer.parseInt(nameAge[1]));
		}
		return person;
	}

	public static Node addFamilyTree(String[] hierarchyArr) throws Exception {

		List<Node> familyTree = new ArrayList<>();
		try {
			if (hierarchyArr != null && hierarchyArr.length > 0) {
				Map<String, String> hierarchyMap = new HashMap<>();
				for (String hier : hierarchyArr) {
					String[] str = hier.split("-");
					hierarchyMap.put(str[0], str[1]);
				}
				if (!hierarchyMap.isEmpty()) {
					Node ggParentNode = null;
					Node gParentNode = null;
					Node parentNode = null;
					Node personNode = null;
					if (hierarchyMap.containsKey("GGP")) {
						ggParentNode = setPerson(hierarchyMap.get("GGP"));
						if (ggParentNode != null) {
							System.out.println("GGP is : " + ggParentNode.getName() + " and age is : " + ggParentNode.getAge());
							familyTree.add(ggParentNode);
						}
					}
					gParentNode = fetchParentRelation(hierarchyMap, ggParentNode, "GP", familyTree);
					parentNode = fetchParentRelation(hierarchyMap, gParentNode, "Parent", familyTree);
					personNode = generatePersonNode(familyTree, hierarchyMap, parentNode);
					familyTree.add(personNode);					
					sortinginDescAsPerAge(familyTree, 0, familyTree.size() -1);
					for (Node node : familyTree) {
						System.out.println("Name is : " + node.getName() + " and Age in Descending Order : " + node.getAge());
					}					
					return personNode;
				} else {
					System.out.println("Please enter a valid input");
				}
			} else {
				System.out.println("Please enter a valid input");
			}

		} catch (Exception e) {
			throw new Exception(e);
		}
		return new PersonNode("", 0);
	}
	
	private static int split(List<Node> familyTree, int begin, int end) {
	    int limit = end;
	    int counter = begin;
	    for (int i = begin; i < end; i++) {
	        if (familyTree.get(i).getAge() > familyTree.get(limit).getAge()) {
	            Node temp = familyTree.get(counter);
	            familyTree.set(counter, familyTree.get(i));
	            familyTree.set(i, temp);
	            counter++;
	        }
	    }
	    Node temp = familyTree.get(limit);
        familyTree.set(limit, familyTree.get(counter));
        familyTree.set(counter, temp);	    
	    return counter;
	}

	public static void sortinginDescAsPerAge(List<Node> familyTree, int begin, int end) {
	    if (end <= begin) return;
	    int limit = split(familyTree, begin, end);
	    sortinginDescAsPerAge(familyTree, begin, limit-1);
	    sortinginDescAsPerAge(familyTree, limit+1, end);
	}
	
	/**
	 * @param familyTree
	 * @param hierarchyMap
	 * @param parentNode
	 * @param personNode
	 * @return
	 */
	private static Node generatePersonNode(List<Node> familyTree, Map<String, String> hierarchyMap,
			Node parentNode) {
		Node personNode = null;
		if (hierarchyMap.containsKey("Person")) {
			personNode = setPerson(hierarchyMap.get("Person"));
			if (parentNode != null && personNode != null) {
				// Adding as parent
				personNode.setParent(parentNode);
				// Adding as child
				parentNode.addChild(personNode);
				System.out.println("Person" + " is : " + personNode.getName() + " and age is : " + personNode.getAge());
				// add Spouse
				if (hierarchyMap.containsKey("Spouse")) {
					Node spouse = setPerson(hierarchyMap.get("Spouse"));
					personNode.setSpouse(spouse);
					System.out.println("Spouse" + " is : " + spouse.getName() + " and age is : " + spouse.getAge());
					familyTree.add(spouse);
				}
				// add Children
				List<Node> childrenNodes = new ArrayList<>();
				if (hierarchyMap.containsKey("Children")) {
					addChildrenToParent(hierarchyMap, childrenNodes, personNode, familyTree);
				}
				personNode.addChildren(childrenNodes);
			}
		}
		return personNode;
	}

	/**
	 * @param hierarchyMap
	 * @param childrenNodes
	 * @param familyTree
	 * @param children
	 */
	private static void addChildrenToParent(Map<String, String> hierarchyMap, List<Node> childrenNodes, Node person,
			List<Node> familyTree) {
		String[] children = hierarchyMap.get("Children").split("!");
		if (children != null && children.length > 0) {
			for (String child : children) {
				Node childNode = setPerson(child);
				if (childNode != null) {
					childNode.setParent(person);
					childrenNodes.add(childNode);
					System.out.println("Child" + " is : " + childNode.getName() + " and age is : " + childNode.getAge());
					familyTree.add(childNode);
					// add GrandChildren
					if (childNode.getName() != null && hierarchyMap.containsKey("GC")) {
						addGrandChild(hierarchyMap, childNode, familyTree);
					}
				}
			}
		}
	}

	/**
	 * @param hierarchyMap
	 * @param childNode
	 * @param familyTree
	 */
	private static void addGrandChild(Map<String, String> hierarchyMap, Node childNode, List<Node> familyTree) {
		String[] grandChildren = hierarchyMap.get("GC").split("#");
		if (grandChildren != null && grandChildren.length > 0 && grandChildren[0].equals(childNode.getName())) {
			String[] grandChildArr = grandChildren[1].split("!");
			if (grandChildArr != null && grandChildArr.length > 0) {
				for (String grandChild : grandChildArr) {
					Node grandChildNode = setPerson(grandChild);
					childNode.addChild(grandChildNode);
					System.out.println("Grand Child " + " is : " + grandChildNode.getName() + " and age is : " + grandChildNode.getAge());
					familyTree.add(grandChildNode);
				}
			}
		}
	}

	/**
	 * @param hierarchyMap
	 * @param familyTree
	 * @param ggParentNode
	 * @param gParentNode
	 * @return
	 */
	private static Node fetchParentRelation(Map<String, String> hierarchyMap, Node parentNode, String identifier,
			List<Node> familyTree) {
		Node node = null;
		if (hierarchyMap.containsKey(identifier)) {
			node = setPerson(hierarchyMap.get(identifier));
			if (parentNode != null && node != null) {
				// Adding as parent
				node.setParent(parentNode);
				// Adding as child
				parentNode.addChild(node);
				System.out.println(identifier + " is : " + node.getName() + " and age is : " + node.getAge());
			}
			familyTree.add(node);
		}
		return node;
	}
}