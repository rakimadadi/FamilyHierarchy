package com.demo.familytree.pojo;

import java.util.ArrayList;
import java.util.List;

public class PersonNode implements Node, Comparable<PersonNode> {

	private final String name;
	private final Integer age;
	private Node spouse;
	private Node root;
	private Node parent;
	private List<Node> children = new ArrayList<>();

	public PersonNode(String name, int age) {
		this.name = name;
		this.age = age;
	}

	@Override
	public Node getRoot() {
		return root;
	}

	@Override
	public void setRoot(Node root) {
		this.root = root;
	}

	@Override
	public List<Node> getChildren() {
		return children;
	}

	@Override
	public void addChild(Node child) {
		this.children.add(child);
		child.setParent(this);
	}

	@Override
	public void addChildren(List<Node> children) {
		this.children.addAll(children);
		for (Node child : children) {
			child.setParent(this);
		}
	}

	@Override
	public Node getParent() {
		return parent;
	}

	@Override
	public void setParent(Node parent) {
		this.parent = parent;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public Integer getAge() {
		return age;
	}

	public void setChildren(List<Node> children) {
		this.children = children;
	}

	@Override
	public Node getSpouse() {
		return spouse;
	}

	@Override
	public void setSpouse(Node spouse) {
		this.spouse = spouse;
	}

	@Override
	public int compareTo(PersonNode o) {
		return 1;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((age == null) ? 0 : age.hashCode());
		result = prime * result + ((children == null) ? 0 : children.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((parent == null) ? 0 : parent.hashCode());
		result = prime * result + ((root == null) ? 0 : root.hashCode());
		result = prime * result + ((spouse == null) ? 0 : spouse.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PersonNode other = (PersonNode) obj;
		if (age == null) {
			if (other.age != null)
				return false;
		} else if (!age.equals(other.age))
			return false;
		if (children == null) {
			if (other.children != null)
				return false;
		} else if (!children.equals(other.children))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (parent == null) {
			if (other.parent != null)
				return false;
		} else if (!parent.equals(other.parent))
			return false;
		if (root == null) {
			if (other.root != null)
				return false;
		} else if (!root.equals(other.root))
			return false;
		if (spouse == null) {
			if (other.spouse != null)
				return false;
		} else if (!spouse.equals(other.spouse))
			return false;
		return true;
	}

}
